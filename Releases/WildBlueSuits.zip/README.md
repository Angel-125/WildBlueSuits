# WildBlueSuits
Spacesuit textures for KSP
License: CC-BY-NC-SA 3.0
Based on the works by Omega486, used with permission
Original textures by Omega486, License: CC-BY-NC-SA 3.0
